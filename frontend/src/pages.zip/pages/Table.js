import React from 'react';
import axios from 'axios';

class Products extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            // haspool_data: [],
            // hasstorageroom_data: [],
            // hasstormprotector_data: [],
            // hasyard_data: [],
            // isnewbuilt_data: [],
            // hasPool: null,
            // hasStorageRoom: null,
            // hasStormProtector: null,
            // hasYard: null,
            // isNewBuilt: null,
            // predict: null,
            // squareMeters: null,
            // numberOfRooms: null,
            // floors: null,
            // cityPartRange: null,
            // numPrevOwners: null,
            // made: null,
            // basement: null,
            // attic: null,
            // garage: null,
            // hasGuestRoom: null,
            // price: 0,

            // cement: null,
            // slag: null,
            // flyash: null,
            // water: null,
            // superplasticizer: null,
            // coarseaggregate: null,
            // fineaggregate: null,
            // age: null,
            // csMPa: 0,

            label: 0,
            fea_1: null,
            fea_2: null,
            fea_3: null,
            int_data: null,
            fea_5: null,
            fea_6: null,
            fea_7: null,
            fea_8: null,
            fea_9: null,
            fea_10: null,
            fea_11: null,
            data: []


        }
    }

    componentDidMount(){
        // this.getHaspool();
        // this.getHasstorageroom();
        // this.getHasstormprotector();
        // this.getHasyard();
        // this.getIsnewbuilt();
        this.getData();
    }

    getData = () => {
        axios.get("http://localhost:3001/data_concrete").then((res) => {
            this.setState({data: res.data.data});
        }).catch((error) => {
            console.log(error);
        });
    }

    // getHaspool = () => {
    //     axios.get("http://localhost:3001/haspool").then((res) => {
    //         this.setState({haspool_data: res.data.data});
    //     }).catch((error) => {
    //         console.log(error);
    //     });
    // }

    // getHasstormprotector = () => {
    //     axios.get("http://localhost:3001/hasstormprotector").then((res) => {
    //         this.setState({hasstormprotector_data: res.data.data});
    //     }).catch((error) => {
    //         console.log(error);
    //     });
    // }

    // getHasstorageroom = () => {
    //     axios.get("http://localhost:3001/hasstorageroom").then((res) => {
    //         this.setState({hasstorageroom_data: res.data.data});
    //     }).catch((error) => {
    //         console.log(error);
    //     });
    // }

    // getHasyard = () => {
    //     axios.get("http://localhost:3001/hasyard").then((res) => {
    //         this.setState({hasyard_data: res.data.data});
    //     }).catch((error) => {
    //         console.log(error);
    //     });
    // }

    // getIsnewbuilt = () => {
    //     axios.get("http://localhost:3001/isnewbuilt").then((res) => {
    //         this.setState({isnewbuilt_data: res.data.data});
    //     }).catch((error) => {
    //         console.log(error);
    //     });
    // }

    handleChange = (e) => {
        console.log(e.target.name, e.target.value);
        let name = e.target.name;
        let value = e.target.value;
        this.setState({
          [name]: value
        });
    }

    handleNumberChange = (e) => {
        console.log(e.target.name, e.target.value);
        let name = e.target.name;
        let value = e.target.value;
        this.setState({
          [name]: parseInt(value)
        });
    }

    handleSubmit = (e) => {
        e.preventDefault();
        axios.post('http://localhost:3001/predict_classification', this.state).then(res => {
          console.log(res.data);
          if(res.data){
            this.setState({
                label: res.data.label
            })
          }
        }).catch(error => {
          console.log(error);
        });
    }

    CreatModelBotton = (e) => {
        axios.get("http://localhost:3001/recreatemodel_classification").then((res) => {
            this.setState({1: res.data.data});
        }).catch((error) => {
            console.log(error);
        });
    }

    handleDelete = (product_id) => {
        console.log(product_id);
        axios.get('http://localhost:8083/admin/delete-products?product_id='+product_id).then(res => {
          console.log(res.data);
          if(res.data.result){
            this.getData();
          }
        }).catch(error => {
          console.log(error);
        });
    }

    render(){
        // console.log(this.state.haspool_data);
        return(
            <main>
                <section class="container py-5">
                    <div class="row text-center pt-3">
                        <div class="col-lg-12 m-auto">
                            <h1 class="h1">Product</h1>
                        </div>
                        <div className='col-md-12'>
                            {/* <Link to="/create-products" className="btn btn-info mb-2">Create</Link> */}
                            <table className="table table-bordered table-striped">
                                <tr style={{textAlign: "center"}}>
                                    <th>ID</th>
                                    <th>cement</th>
                                    <th>slag</th>
                                    <th>flyash</th>
                                    <th>water</th>
                                    <th>superplasticizer</th>
                                    <th>coarseaggregate</th>
                                    <th>fineaggregate</th>
                                    <th>age</th>
                                    <th>csMPa</th>
                                    <th>Option</th>
                                </tr>
                                {this.state.data.map(item => (
                                    <tr>
                                        <th>{item.ID}</th>
                                        <th>{item.cement}</th>
                                        <th>{item.slag}</th>
                                        <th>{item.flyash}</th> 
                                        <th>{item.water}</th> 
                                        <th>{item.superplasticizer}</th> 
                                        <th>{item.coarseaggregate}</th> 
                                        <th>{item.fineaggregate}</th> 
                                        <th>{item.age}</th> 
                                        <th>{item.csMPa}</th> 
                                        <th>
                                            <Link to={"/update-products/"+item.product_id} className="btn btn-info mb-1" style={{background: "#17A2B8", width: "100%"}}>Edit</Link> 
                                            <button className="btn btn-danger" style={{background: "#BE2535", width: "100%"}} onClick={() => { if (window.confirm('Are you sure you wish to delete this item?')) this.handleDelete(item.ID) } }>Delete</button>
                                        </th>
                                    </tr>
                                ))}
                            </table>
                        </div>
                    </div>
                </section>
            </main>
        )
    }
}

export default Products;